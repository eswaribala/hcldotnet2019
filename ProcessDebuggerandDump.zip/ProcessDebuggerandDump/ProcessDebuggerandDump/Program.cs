﻿using Microsoft.Samples.Debugging.CorDebug;
using Microsoft.Samples.Debugging.MdbgEngine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ProcessDebuggerandDump
{
    class Program
    {
        static void Main(string[] args)
        {
            var stop = new ManualResetEvent(false);
            var engine = new MDbgEngine();
            var process = engine.CreateProcess("G:/Local disk/dotnetperformance/HotelManagement/bin/Debug/Hotel_Manager.exe", "", DebugModeFlag.Default, null);
            process.Go();

            process.PostDebugEvent +=
                (sender, e) =>
                {
                    if (e.CallbackType == ManagedCallbackType.OnBreakpoint)
                        process.Go();

                    if (e.CallbackType == ManagedCallbackType.OnException2)
                    {
                        //ClrDump.CreateDump(process.CorProcess.Id, @"C:\temp.dmp", (int)MINIDUMP_TYPE.MiniDumpWithFullMemory, 0, IntPtr.Zero);
                    }

                    if (e.CallbackType == ManagedCallbackType.OnProcessExit)
                        stop.Set();
                };

            stop.WaitOne();
        }
    }
}
