﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ThreadPoorManagement
{
    class Program
    {
        static void Main()
        {
            while (true)
            {
                Console.WriteLine("Press <ENTER> to start a thread...");
                Console.ReadLine();
                Thread t = new Thread(new ThreadStart(ThreadProc));
                t.Start();
            }
        }

        static void ThreadProc()
        {
            Console.WriteLine("Thread #{0} started...", Thread.CurrentThread.ManagedThreadId);
            // Block the thread
            Thread.CurrentThread.Join();
        }
    }
}
