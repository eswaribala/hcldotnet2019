﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MenuStack
{
    /// <summary>
    /// Interaction logic for EXIT.xaml
    /// </summary>
    public partial class EXIT : UserControl
    {
        public EXIT()
        {
            InitializeComponent();
            DataTable dt = DataStoreDllDemo.OracleConnector.FillDataGrid();
            dataGrid1.ItemsSource = dt.AsDataView();
        }
    }
}
