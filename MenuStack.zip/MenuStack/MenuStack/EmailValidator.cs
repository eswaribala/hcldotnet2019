﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace MenuStack
{
    class EmailValidator : ValidationRule
    {
        private String _regex = @"^\w+@((\w+[\.]\w+)+|\w+)\.(\w+([.]\w+))|(\w+)$";

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            if (String.IsNullOrEmpty(value.ToString()))
                return new ValidationResult(false, "value cannot be empty.");
            else
            {
                if (!Regex.IsMatch(value.ToString(), _regex))
                    return new ValidationResult(false, "Enter valid Email Address");
            }
           return ValidationResult.ValidResult;
        }
    }
}
