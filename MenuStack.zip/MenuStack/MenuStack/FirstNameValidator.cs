﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace MenuStack
{
    class FirstNameValidator : ValidationRule
    {
        private string _regex = @"^[A-Za-z]{5,25}$";
        public override ValidationResult Validate
      (object value, System.Globalization.CultureInfo cultureInfo)
        {
            //if (value == null)
            //    return new ValidationResult(false, "value cannot be empty.");
            //else
            //{
            //    if (value.ToString().Length > 3)
            //        return new ValidationResult
            //        (false, "Name cannot be more than 3 characters long.");
            //}
           
            if (String.IsNullOrEmpty(value.ToString()))
                return new ValidationResult(false, "value cannot be empty.");
            else
            {
                if (!Regex.IsMatch(value.ToString(), _regex))
                    return new ValidationResult(false, "Enter name Only in chars");
            }
            return ValidationResult.ValidResult;
        }

    }
}
