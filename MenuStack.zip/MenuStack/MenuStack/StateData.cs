﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MenuStack
{
    public class StateData
    {


        public static IList<String> getStates()
        {
            IList<String> stateList = new List<String>();
            stateList.Add("TamilNadu");
            stateList.Add("Karnatka");
            stateList.Add("Kerala");
            stateList.Add("Maharastra");
            stateList.Add("Madhya Pradesh");
            stateList.Add("Haryana");
            return stateList;

        }


    }
}
