﻿
using DataStoreDllDemo;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MenuStack
{
    /// <summary>
    /// Interaction logic for CURRENT_SETTINGS.xaml
    /// </summary>
    public partial class CURRENT_SETTINGS : UserControl
    {
        
        public CURRENT_SETTINGS()
        {
            InitializeComponent();
            stateList.ItemsSource = StateData.getStates();
            DataContext = new CONT_USER();
            
           
        }
       
       
       
      

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Select a picture";
            ofd.Filter = "All supported graphics|*.jpg;*.jpeg;*.png|" +
              "JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg|" +
              "Portable Network Graphic (*.png)|*.png";
            if(ofd.ShowDialog()==true)
            {
                imgPhoto.Source = new BitmapImage(new Uri(ofd.FileName));
                //this.fileName = ofd.FileName;

                var vm = DataContext as CONT_USER;
                vm.ProfilePhoto = ofd.FileName;
                profilePhoto.Text = vm.ProfilePhoto;
            }

        }

       
    }
}
