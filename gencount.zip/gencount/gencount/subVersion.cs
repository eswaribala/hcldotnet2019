﻿namespace GCCollectExample
{
    internal class SubVersion
    {
    }
}