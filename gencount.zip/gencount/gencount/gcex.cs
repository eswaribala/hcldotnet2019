using System;

namespace GCCollectExample
{
    class MyGCCollectClass
    {
        private const int maxGarbage = 1000;

        public static void GcTest()
        {
            // Put some objects in memory.
		
 		MyGCCollectClass My= new  MyGCCollectClass();
            My.MakeSomeGarbage();
            Console.WriteLine("Memory used before collection: {0}", GC.GetTotalMemory(false));

            // Collect all generations of memory.

            GC.Collect(0);
            Console.WriteLine("Memory used after full collection: {0}", GC.GetTotalMemory(true));
            
        }

         void MakeSomeGarbage()
        {
           SubVersion vt=null;

            for(int i = 0; i < maxGarbage; i++)
            {
                // Create objects and release them to fill up memory
                // with unused objects.
                vt = new SubVersion();
            }
        }

         ~MyGCCollectClass()
            {

                 Console.WriteLine("Destroying");

		}
    }
}

