﻿using GCCollectExample;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gencount
{
    class Program
    {

        static void gencount()
        {
            try
            {
                Console.WriteLine("GC Maximum Generations:" + GC.MaxGeneration);
                Console.WriteLine("Total Memory:" + GC.GetTotalMemory(false));
                Program oBaseGC = new Program();
                Console.WriteLine("BaseGC Generation is :" + GC.GetGeneration(oBaseGC));
                Console.WriteLine("Total Memory:" + GC.GetTotalMemory(false));
                Console.WriteLine("Garbage Collection Occured in 0th Generation:" + GC.CollectionCount(0));
                Console.WriteLine("Garbage Collection Occured in 1th Generation:" + GC.CollectionCount(1));
                Console.WriteLine("Garbage Collection Occured in 2th Generation:" + GC.CollectionCount(2));
                GC.Collect(0);
                Console.WriteLine("Garbage Collection Occured in 0th Generation:" + GC.CollectionCount(0));
                MyGCCollectClass.GcTest();
            }
            catch (Exception oEx)
            {
                Console.WriteLine("Error:" + oEx.Message);
            }

        }
        static void Main(string[] args)
        {
            gencount();
            Console.ReadLine();
        }
    }
}
